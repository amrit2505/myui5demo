sap.ui.define(
    ["tom/controller/BaseController",
     "sap/m/MessageToast"
    ],
    function (BaseController, MessageToast) {
        return BaseController.extend("tom.controller.Add",
            {
                onInit: function () {
                    this._localModel = this.getOwnerComponent().getModel("local");

                },
                onDelete: function(){
                    var productId = this._localModel.getProperty("/newProduct/ProductId");
                    var oDataModel = this.getOwnerComponent().getModel();
                    oDataModel.remove("/ProductSet('" + productId + "')",{
                        success: function(){
                            MessageToast.show("The delete was successful, yey !!");
                        },
                        error : function(){

                        }

                    });
                },
                onSave: function(){
                    //Step 1 :- Get the Odata Model Object
                    var oDataModel = this.getOwnerComponent().getModel();
                    //Step 2 :- Prepare the payload
                    var payload = this._localModel.getProperty("/newProduct");
                    //Step 3 :- fire Post call using create method
                    oDataModel.create("/ProductSet", payload, {
                        success: function(){
                            MessageToast.show("The product has been created in SAP !!!");
                        },
                        error: function(){

                        }
                    });
                }
            }

        )
    }
);