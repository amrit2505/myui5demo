sap.ui.define(
    ["sap/ui/core/UIComponent"],
    function (UIComponent) {
        return UIComponent.extend("tom.Component",
            {
                metadata: {
                    manifest: "json"
                },
                init: function () {
                    //In this child class constructor, I want to call base class contructor,
                    //Base Class has a lots of power, untill I call, I won't get it
                    UIComponent.prototype.init.apply(this);

                    this.oRouter = this.getRouter();
                    this.oRouter.initialize();

                },
                // createContent: function () {
                //     var oView = new sap.ui.view({
                //         viewName: "tom.view.App",
                //         type: "XML"
                //     });
                //     //Step 1 :- Get the container control oobject which is inside the App View
                //     var oContainer = oView.byId("idApp");
                //     //Step 2 :- Create the objects of oue new views
                //     var oView1 = new sap.ui.view({
                //         viewName: "tom.view.View1",
                //         id: "idView1",
                //         type: "XML"
                //     });
                //     var oView2 = new sap.ui.view({
                //         viewName: "tom.view.View2",
                //         id: "idView2",
                //         type: "XML"
                //     });

                //     //Step 3 :- Add our views directly to the container control
                //     oContainer.addPage(oView1);
                //     oContainer.addPage(oView2);

                //     return oView;
                // },
                destroy: function () {

                }
            }
        );
    }
);